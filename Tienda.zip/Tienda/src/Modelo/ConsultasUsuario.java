package Modelo;

import java.sql.*;

public class ConsultasUsuario extends Conexion {

    public boolean registrar(Usuario user) {
        PreparedStatement ps = null;
        Connection con = getConexion();
        String sql = "INSERT INTO usuario (id, nombre, correo, contrasenna) VALUES (?, ?, ?, ?)";

        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, user.getId());
            ps.setString(2, user.getNombre());
            ps.setString(3, user.getCorreo());
            ps.setString(4, user.getContrasenna());
            ps.execute();
            return true;

        } catch (SQLException e) {
            System.out.println("Error al registrar: " + e.getMessage());
            return false;

        } finally {
            try { con.close(); } catch (SQLException e) {}
        }
    }

    public boolean validarContrasenna(String contrasenna) {
        String regex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).+$";
        return contrasenna.matches(regex);
    }

    public boolean iniciarSesion(String correo, String contrasenna) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConexion();

        try {
            String sql = "SELECT * FROM usuario WHERE correo = ? AND contrasenna = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, correo);
            ps.setString(2, contrasenna);

            rs = ps.executeQuery();

            return rs.next();

        } catch (SQLException e) {
            System.out.println("Error en login: " + e);
            return false;

        } finally {
            try { if (rs != null) rs.close(); } catch (SQLException e) {}
            try { if (ps != null) ps.close(); } catch (SQLException e) {}
            try { con.close(); } catch (SQLException e) {}
        }
    }
}
