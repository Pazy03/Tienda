/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Consultas para la tabla proveedor.
 * Creado por María Paz García
 */
public class ConsultasProveedor extends Conexion {
    
    public boolean registrar(Proveedor proveedor) {
        String sql = "INSERT INTO proveedor (nombre, telefono, correo, direccion) VALUES (?, ?, ?, ?)";
        
        try (Connection con = getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setString(1, proveedor.getNombre());
            ps.setString(2, proveedor.getTelefono());
            ps.setString(3, proveedor.getCorreo());
            ps.setString(4, proveedor.getDireccion());
            ps.execute();
            return true;
            
        } catch (SQLException e) {
            System.err.println("Error al registrar proveedor: " + e);
            return false;
        }
    }
    
    public ArrayList<Proveedor> listar() {
        ArrayList<Proveedor> lista = new ArrayList<>();
        String sql = "SELECT * FROM proveedor";
        
        try (Connection con = getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                Proveedor p = new Proveedor();
                p.setId(rs.getInt("id"));
                p.setNombre(rs.getString("nombre"));
                p.setTelefono(rs.getString("telefono"));
                p.setCorreo(rs.getString("correo"));
                p.setDireccion(rs.getString("direccion"));
                lista.add(p);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al listar proveedores: " + e);
        }
        
        return lista;
    }
}

