/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Consultas para la tabla colaborador.
 * Creado por María Paz García
 */
public class ConsultasColaborador extends Conexion {

    public boolean registrar(Colaborador colab) {
        String sql = "INSERT INTO colaborador (nombre, correo, rol) VALUES (?, ?, ?)";

        try (Connection con = getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, colab.getNombre());
            ps.setString(2, colab.getCorreo());
            ps.setString(3, colab.getRol());
            ps.execute();
            return true;

        } catch (SQLException e) {
            System.err.println("Error al registrar colaborador: " + e);
            return false;
        }
    }

    public ArrayList<Colaborador> listar() {
        ArrayList<Colaborador> lista = new ArrayList<>();
        String sql = "SELECT * FROM colaborador";

        try (Connection con = getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Colaborador c = new Colaborador();
                c.setId(rs.getInt("id"));
                c.setNombre(rs.getString("nombre"));
                c.setCorreo(rs.getString("correo"));
                c.setRol(rs.getString("rol"));
                lista.add(c);
            }

        } catch (SQLException e) {
            System.err.println("Error al listar colaboradores: " + e);
        }

        return lista;
    }
}
