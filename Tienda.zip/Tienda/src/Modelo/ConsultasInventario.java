/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Consultas para el inventario.
 * Creado por María Paz García.
 */
public class ConsultasInventario extends Conexion {

    // Listar todos los productos
    public ArrayList<Inventario> listar() {
        ArrayList<Inventario> lista = new ArrayList<>();
        String sql = "SELECT * FROM inventario";

        try (Connection con = getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Inventario inv = new Inventario();
                inv.setId(rs.getInt("id"));
                inv.setNombreProducto(rs.getString("nombre_producto"));
                inv.setCantidad(rs.getInt("cantidad"));
                lista.add(inv);
            }

        } catch (SQLException e) {
            System.err.println("Error listando inventario: " + e);
        }

        return lista;
    }

    // Actualizar la cantidad
    public boolean actualizar(Inventario inv) {
        String sql = "UPDATE inventario SET cantidad = ? WHERE id = ?";

        try (Connection con = getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, inv.getCantidad());
            ps.setInt(2, inv.getId());
            ps.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.err.println("Error actualizando inventario: " + e);
            return false;
        }
    }
}

