/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author zunij
 */
public class Usuario {
    
    private int id;
    private String nombre;
   private String correo;
   private String contrasenna;

    public Usuario() {
        this.id = 0;
        this.nombre = "";
        this.correo = "";
        this.contrasenna = "";
    }
   
   public Usuario(int id, String nombre, String correo, String contrasenna) {
        this.id = id;
        this.nombre = nombre;
        this.correo = correo;
        this.contrasenna = contrasenna;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContrasenna() {
        return contrasenna;
    }

    public void setContrasenna(String contrasenna) {
        this.contrasenna = contrasenna;
    }
   
   
}
