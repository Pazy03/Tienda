/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 * Modelo de puntos del cliente.
 * Creado por María Paz García.
 */
public class PuntosCliente {

    private int id;
    private int idUsuario;
    private int puntos;

    public PuntosCliente() {
    }

    public PuntosCliente(int id, int idUsuario, int puntos) {
        this.id = id;
        this.idUsuario = idUsuario;
        this.puntos = puntos;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }
}

