/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import javax.swing.*;

public class frmLealtad extends JFrame {

    public JTextField txtIdCliente;
    public JTextField txtPuntos;
    public JButton btnGuardar;

    public frmLealtad() {

        setTitle("Plan de Lealtad");
        setSize(400, 250);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel lblTitulo = new JLabel("Gestión de Lealtad");
        lblTitulo.setBounds(130, 10, 200, 25);
        add(lblTitulo);

        JLabel lblIdCliente = new JLabel("ID Cliente:");
        lblIdCliente.setBounds(30, 60, 120, 25);
        add(lblIdCliente);

        txtIdCliente = new JTextField();
        txtIdCliente.setBounds(150, 60, 200, 25);
        add(txtIdCliente);

        JLabel lblPuntos = new JLabel("Puntos:");
        lblPuntos.setBounds(30, 100, 120, 25);
        add(lblPuntos);

        txtPuntos = new JTextField();
        txtPuntos.setBounds(150, 100, 200, 25);
        add(txtPuntos);

        btnGuardar = new JButton("Guardar");
        btnGuardar.setBounds(150, 150, 200, 30);
        add(btnGuardar);
    }
}

