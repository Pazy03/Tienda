/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import javax.swing.*;

/**
 * Formulario de gestión de productos.
 * Creado por María Paz García.
 */
public class frmProducto extends JFrame {

    public JTextField txtIdProducto;
    public JTextField txtNombreProducto;
    public JTextField txtPrecio;
    public JButton btnRegistrar;
    public JButton btnActualizar;
    public JButton btnEliminar;

    public frmProducto() {

        setTitle("Gestión de Productos");
        setSize(450, 350);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel lblTitulo = new JLabel("Gestión de Productos");
        lblTitulo.setBounds(150, 10, 250, 25);
        add(lblTitulo);

        JLabel lblId = new JLabel("ID Producto:");
        lblId.setBounds(30, 60, 120, 25);
        add(lblId);

        txtIdProducto = new JTextField();
        txtIdProducto.setBounds(150, 60, 250, 25);
        add(txtIdProducto);

        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(30, 100, 120, 25);
        add(lblNombre);

        txtNombreProducto = new JTextField();
        txtNombreProducto.setBounds(150, 100, 250, 25);
        add(txtNombreProducto);

        JLabel lblPrecio = new JLabel("Precio:");
        lblPrecio.setBounds(30, 140, 120, 25);
        add(lblPrecio);

        txtPrecio = new JTextField();
        txtPrecio.setBounds(150, 140, 250, 25);
        add(txtPrecio);

        btnRegistrar = new JButton("Registrar");
        btnRegistrar.setBounds(30, 210, 110, 35);
        add(btnRegistrar);

        btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(165, 210, 110, 35);
        add(btnActualizar);

        btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(300, 210, 110, 35);
        add(btnEliminar);
    }
}

