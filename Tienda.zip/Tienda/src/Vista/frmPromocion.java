/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import javax.swing.*;

public class frmPromocion extends JFrame {

    public JTextField txtIdProducto;
    public JTextField txtNombrePromo;
    public JTextField txtDescuento;
    public JButton btnGuardar;

    public frmPromocion() {

        setTitle("Registro de Promociones");
        setSize(450, 280);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel lblTitulo = new JLabel("Registrar Promoción");
        lblTitulo.setBounds(150, 10, 200, 25);
        add(lblTitulo);

        JLabel lblIdProducto = new JLabel("ID Producto:");
        lblIdProducto.setBounds(30, 60, 140, 25);
        add(lblIdProducto);

        txtIdProducto = new JTextField();
        txtIdProducto.setBounds(160, 60, 230, 25);
        add(txtIdProducto);

        JLabel lblNombrePromo = new JLabel("Nombre Promo:");
        lblNombrePromo.setBounds(30, 100, 140, 25);
        add(lblNombrePromo);

        txtNombrePromo = new JTextField();
        txtNombrePromo.setBounds(160, 100, 230, 25);
        add(txtNombrePromo);

        JLabel lblDescuento = new JLabel("Descuento %:");
        lblDescuento.setBounds(30, 140, 140, 25);
        add(lblDescuento);

        txtDescuento = new JTextField();
        txtDescuento.setBounds(160, 140, 230, 25);
        add(txtDescuento);

        btnGuardar = new JButton("Guardar");
        btnGuardar.setBounds(160, 190, 230, 30);
        add(btnGuardar);
    }
}

