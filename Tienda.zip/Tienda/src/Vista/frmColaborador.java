/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import javax.swing.*;

public class frmColaborador extends JFrame {

    
    public JTextField txtId;
    public JTextField txtNombre;
    public JTextField txtCorreo;
    public JButton btnRegistrar;

    public frmColaborador() {

        setTitle("Registro de Colaboradores");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel lblTitulo = new JLabel("Registrar Colaborador");
        lblTitulo.setBounds(120, 10, 200, 30);
        add(lblTitulo);

        JLabel lblId = new JLabel("Cédula:");
        lblId.setBounds(30, 60, 100, 25);
        add(lblId);

        txtId = new JTextField();
        txtId.setBounds(130, 60, 200, 25);
        add(txtId);

        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(30, 100, 100, 25);
        add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(130, 100, 200, 25);
        add(txtNombre);

        JLabel lblCorreo = new JLabel("Correo:");
        lblCorreo.setBounds(30, 140, 100, 25);
        add(lblCorreo);

        txtCorreo = new JTextField();
        txtCorreo.setBounds(130, 140, 200, 25);
        add(txtCorreo);

        btnRegistrar = new JButton("Registrar");
        btnRegistrar.setBounds(130, 190, 200, 30);
        add(btnRegistrar);
    }
}

