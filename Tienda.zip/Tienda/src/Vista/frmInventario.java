/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import javax.swing.*;

public class frmInventario extends JFrame {

    public JTextField txtIdProducto;
    public JTextField txtNombreProducto;
    public JTextField txtCantidad;
    public JButton btnRegistrar;
    public JButton btnActualizar;
    public JButton btnEliminar;

    public frmInventario() {

        setTitle("Gestión de Inventario");
        setSize(450, 320);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel lblTitulo = new JLabel("Inventario de Productos");
        lblTitulo.setBounds(150, 10, 250, 25);
        add(lblTitulo);

        JLabel lblIdProducto = new JLabel("ID Producto:");
        lblIdProducto.setBounds(30, 60, 120, 25);
        add(lblIdProducto);

        txtIdProducto = new JTextField();
        txtIdProducto.setBounds(150, 60, 250, 25);
        add(txtIdProducto);

        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(30, 100, 120, 25);
        add(lblNombre);

        txtNombreProducto = new JTextField();
        txtNombreProducto.setBounds(150, 100, 250, 25);
        add(txtNombreProducto);

        JLabel lblCantidad = new JLabel("Cantidad:");
        lblCantidad.setBounds(30, 140, 120, 25);
        add(lblCantidad);

        txtCantidad = new JTextField();
        txtCantidad.setBounds(150, 140, 250, 25);
        add(txtCantidad);

        btnRegistrar = new JButton("Registrar");
        btnRegistrar.setBounds(30, 200, 110, 35);
        add(btnRegistrar);

        btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(165, 200, 110, 35);
        add(btnActualizar);

        btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(300, 200, 110, 35);
        add(btnEliminar);
    }
}

