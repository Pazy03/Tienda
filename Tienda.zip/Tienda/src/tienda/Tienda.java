package tienda;

import Controlador.ctrlUsario;
import Modelo.ConsultasUsuario;
import Modelo.Usuario;
import Vista.frmRegistrar;
import Vista.frmLogin;

import Modelo.PuntosCliente;
import Modelo.ConsultasPuntosCliente;
import Vista.frmLealtad;
import Controlador.ctrlLealtad;

import Modelo.Inventario;
import Modelo.ConsultasInventario;
import Vista.frmInventario;
import Controlador.ctrlInventario;

/**
 *
 * modificado por María Paz García.
 */
public class Tienda {

    public static void main(String[] args) {

        // Inicio del sistema con login
        Usuario mod = new Usuario();
        ConsultasUsuario modC = new ConsultasUsuario();
        frmRegistrar frm1 = new frmRegistrar();
        frmLogin frm2 = new frmLogin();

        ctrlUsario ctrl = new ctrlUsario(mod, modC, frm1, frm2);

        frm2.setLocationRelativeTo(null);
        frm2.setVisible(true);
    }

    /**
     * ABRIR VISTA DE COLABORADORES
     */
    public static void abrirColaboradores() {
        Modelo.Colaborador modelo = new Modelo.Colaborador();
        Modelo.ConsultasColaborador consultas = new Modelo.ConsultasColaborador();
        Vista.frmColaborador vista = new Vista.frmColaborador();
        Controlador.ctrlColaborador controlador = new Controlador.ctrlColaborador(modelo, consultas, vista);
        controlador.iniciar();
    }

    /**
     * ABRIR VISTA DE LEALTAD
     */
    public static void abrirLealtad() {
        PuntosCliente modelo = new PuntosCliente();
        ConsultasPuntosCliente consultas = new ConsultasPuntosCliente();
        frmLealtad vista = new frmLealtad();
        ctrlLealtad controlador = new ctrlLealtad(modelo, consultas, vista);
        controlador.iniciar();
    }

    /**
     * ABRIR VISTA DE INVENTARIO
     */
    public static void abrirInventario() {
        Inventario modelo = new Inventario();
        ConsultasInventario consultas = new ConsultasInventario();
        frmInventario vista = new frmInventario();
        ctrlInventario controlador = new ctrlInventario(modelo, consultas, vista);
        controlador.iniciar();
    }
}
