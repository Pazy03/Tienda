/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.PuntosCliente;
import Modelo.ConsultasPuntosCliente;
import Vista.frmLealtad;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 * Controlador para el plan de lealtad.
 * Creado por María Paz García.
 */
public class ctrlLealtad implements ActionListener {

    private PuntosCliente modelo;
    private ConsultasPuntosCliente consultas;
    private frmLealtad vista;

    public ctrlLealtad(PuntosCliente modelo, ConsultasPuntosCliente consultas, frmLealtad vista) {
        this.modelo = modelo;
        this.consultas = consultas;
        this.vista = vista;

        this.vista.btnGuardar.addActionListener(this);
    }

    // MÉTODO PARA MOSTRAR EL FORMULARIO
    public void iniciar() {
        vista.setTitle("Gestión de Lealtad");
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == vista.btnGuardar) {

            modelo.setIdUsuario(Integer.parseInt(vista.txtIdCliente.getText()));
            modelo.setPuntos(Integer.parseInt(vista.txtPuntos.getText()));

            if (consultas.actualizarPuntos(modelo)) {
                JOptionPane.showMessageDialog(null, "Puntos actualizados correctamente");
                vista.txtIdCliente.setText("");
                vista.txtPuntos.setText("");
            } else {
                JOptionPane.showMessageDialog(null, "Error al actualizar puntos");
            }
        }
    }
}

