package Controlador;

import Modelo.Producto;
import Modelo.ConsultasProducto;
import Vista.frmProducto;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 * Controlador de Productos.
 * Creado por María Paz García.
 */
public class ctrlProducto implements ActionListener {

    private Producto modelo;
    private ConsultasProducto consultas;
    private frmProducto vista;

    public ctrlProducto(Producto modelo, ConsultasProducto consultas, frmProducto vista) {
        this.modelo = modelo;
        this.consultas = consultas;
        this.vista = vista;

        this.vista.btnRegistrar.addActionListener(this);
        this.vista.btnActualizar.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
    }

    // Inicia la vista
    public void iniciar() {
        vista.setTitle("Gestión de Productos");
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        // REGISTRAR
        if (e.getSource() == vista.btnRegistrar) {

            modelo.setIdProducto(Integer.parseInt(vista.txtIdProducto.getText()));
            modelo.setNombre(vista.txtNombreProducto.getText());
            modelo.setPrecio(Double.parseDouble(vista.txtPrecio.getText()));

            if (consultas.registrar(modelo)) {
                JOptionPane.showMessageDialog(null, "Producto registrado correctamente");
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(null, "Error al registrar producto");
            }
        }

        // ACTUALIZAR
        if (e.getSource() == vista.btnActualizar) {

            modelo.setIdProducto(Integer.parseInt(vista.txtIdProducto.getText()));
            modelo.setNombre(vista.txtNombreProducto.getText());
            modelo.setPrecio(Double.parseDouble(vista.txtPrecio.getText()));

            if (consultas.actualizar(modelo)) {
                JOptionPane.showMessageDialog(null, "Producto actualizado correctamente");
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(null, "Error al actualizar producto");
            }
        }

        // ELIMINAR
        if (e.getSource() == vista.btnEliminar) {

            int id = Integer.parseInt(vista.txtIdProducto.getText());

            if (consultas.eliminar(id)) {
                JOptionPane.showMessageDialog(null, "Producto eliminado correctamente");
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(null, "Error al eliminar producto");
            }
        }
    }

    private void limpiarCampos() {
        vista.txtIdProducto.setText("");
        vista.txtNombreProducto.setText("");
        vista.txtPrecio.setText("");
    }
}
