/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Inventario;
import Modelo.ConsultasInventario;
import Vista.frmInventario;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class ctrlInventario implements ActionListener {

    private Inventario modelo;
    private ConsultasInventario consultas;
    private frmInventario vista;

    public ctrlInventario(Inventario modelo, ConsultasInventario consultas, frmInventario vista) {
        this.modelo = modelo;
        this.consultas = consultas;
        this.vista = vista;

        this.vista.btnRegistrar.addActionListener(this);
        this.vista.btnActualizar.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
    }

    public void iniciar() {
        vista.setVisible(true);
        vista.setLocationRelativeTo(null);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == vista.btnRegistrar) {
            modelo.setId_producto(Integer.parseInt(vista.txtIdProducto.getText()));
            modelo.setNombre(vista.txtNombreProducto.getText());
            modelo.setCantidad(Integer.parseInt(vista.txtCantidad.getText()));

            if (consultas.registrar(modelo)) {
                JOptionPane.showMessageDialog(null, "Producto registrado");
            } else {
                JOptionPane.showMessageDialog(null, "Error al registrar");
            }
        }

        if (e.getSource() == vista.btnActualizar) {
            modelo.setId_producto(Integer.parseInt(vista.txtIdProducto.getText()));
            modelo.setNombre(vista.txtNombreProducto.getText());
            modelo.setCantidad(Integer.parseInt(vista.txtCantidad.getText()));

            if (consultas.actualizar(modelo)) {
                JOptionPane.showMessageDialog(null, "Producto actualizado");
            } else {
                JOptionPane.showMessageDialog(null, "Error al actualizar");
            }
        }

        if (e.getSource() == vista.btnEliminar) {
            modelo.setId_producto(Integer.parseInt(vista.txtIdProducto.getText()));

            if (consultas.eliminar(modelo)) {
                JOptionPane.showMessageDialog(null, "Producto eliminado");
            } else {
                JOptionPane.showMessageDialog(null, "Error al eliminar");
            }
        }
    }
}

