/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Categoria;
import Modelo.ConsultasCategoria;
import Vista.frmCategoria;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 * Controlador de categorías.
 * Creado por María Paz García
 */
public class ctrlCategoria implements ActionListener {

    private Categoria modelo;
    private ConsultasCategoria consultas;
    private frmCategoria vista;

    public ctrlCategoria(Categoria modelo, ConsultasCategoria consultas, frmCategoria vista) {
        this.modelo = modelo;
        this.consultas = consultas;
        this.vista = vista;

        this.vista.btnGuardar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == vista.btnGuardar) {

            modelo.setNombre(vista.txtNombre.getText());
            modelo.setDescripcion(vista.txtDescripcion.getText());

            if (consultas.registrar(modelo)) {
                JOptionPane.showMessageDialog(null, "Categoría registrada correctamente");
                vista.txtNombre.setText("");
                vista.txtDescripcion.setText("");
            } else {
                JOptionPane.showMessageDialog(null, "Error al registrar categoría");
            }
        }
    }
}

