package Controlador;

import Modelo.Colaborador;
import Modelo.ConsultasColaborador;
import Vista.frmColaborador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 * Controlador de Colaboradores
 * Creado por María Paz García.
 */
public class ctrlColaborador implements ActionListener {

    private Colaborador modelo;
    private ConsultasColaborador consultas;
    private frmColaborador vista;

    public ctrlColaborador(Colaborador modelo, ConsultasColaborador consultas, frmColaborador vista) {
        this.modelo = modelo;
        this.consultas = consultas;
        this.vista = vista;

        // Asignación de eventos
        this.vista.btnRegistrar.addActionListener(this);
        this.vista.btnActualizar.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
    }

    // Configurar la vista
    public void iniciar() {
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        // REGISTRAR
        if (e.getSource() == vista.btnRegistrar) {
            modelo.setIdColaborador(Integer.parseInt(vista.txtIdColaborador.getText()));
            modelo.setNombre(vista.txtNombre.getText());
            modelo.setCorreo(vista.txtCorreo.getText());

            if (consultas.registrar(modelo)) {
                JOptionPane.showMessageDialog(null, "Colaborador registrado correctamente.");
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(null, "Error al registrar colaborador.");
            }
        }

        // ACTUALIZAR
        if (e.getSource() == vista.btnActualizar) {
            modelo.setIdColaborador(Integer.parseInt(vista.txtIdColaborador.getText()));
            modelo.setNombre(vista.txtNombre.getText());
            modelo.setCorreo(vista.txtCorreo.getText());

            if (consultas.actualizar(modelo)) {
                JOptionPane.showMessageDialog(null, "Datos actualizados correctamente.");
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(null, "Error al actualizar datos.");
            }
        }

        // ELIMINAR
        if (e.getSource() == vista.btnEliminar) {

            int id = Integer.parseInt(vista.txtIdColaborador.getText());

            if (consultas.eliminar(id)) {
                JOptionPane.showMessageDialog(null, "Colaborador eliminado.");
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(null, "Error al eliminar colaborador.");
            }
        }
    }

    // Método reutilizable
    private void limpiarCampos() {
        vista.txtIdColaborador.setText("");
        vista.txtNombre.setText("");
        vista.txtCorreo.setText("");
    }
}
