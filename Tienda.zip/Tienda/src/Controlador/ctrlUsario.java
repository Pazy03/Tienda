package Controlador;

import Modelo.ConsultasUsuario;
import Modelo.Usuario;
import Vista.frmRegistrar;
import Vista.frmLogin;
import tienda.Tienda;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class ctrlUsuario implements ActionListener {

    private final Usuario modelo;
    private final ConsultasUsuario consultas;
    private final frmRegistrar vistaR;
    private final frmLogin vistaL;

    public ctrlUsuario(Usuario modelo, ConsultasUsuario consultas, frmRegistrar vistaR, frmLogin vistaL) {
        this.modelo = modelo;
        this.consultas = consultas;
        this.vistaR = vistaR;
        this.vistaL = vistaL;

        // botones
        this.vistaR.btnCrearCuenta.addActionListener(this);
        this.vistaL.btnLogin.addActionListener(this);
        this.vistaL.btnRegistrar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        /* ----------------- REGISTRO ----------------- */
        if (e.getSource() == vistaR.btnCrearCuenta) {

            String pass1 = String.valueOf(vistaR.txtContrasenna1.getPassword());
            String pass2 = String.valueOf(vistaR.txtContrasenna2.getPassword());

            if (!pass1.equals(pass2)) {
                JOptionPane.showMessageDialog(null,
                        "Las contraseñas deben ser iguales.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!consultas.validarContrasenna(pass1)) {
                JOptionPane.showMessageDialog(null,
                        "La contraseña debe incluir mayúsculas, minúsculas y números.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            modelo.setId(Integer.parseInt(vistaR.txtCedula.getText()));
            modelo.setNombre(vistaR.txtNombre.getText());
            modelo.setCorreo(vistaR.txtCorreo.getText());
            modelo.setContrasenna(pass1);

            if (consultas.registrar(modelo)) {
                JOptionPane.showMessageDialog(null, "Usuario registrado correctamente.");
                limpiarRegistro();
                vistaR.dispose();
            } else {
                JOptionPane.showMessageDialog(null, "Error al registrar usuario.");
            }
        }

        /* ----------------- LOGIN ----------------- */
        if (e.getSource() == vistaL.btnLogin) {

            String correo = vistaL.txtCorreo.getText();
            String contrasenna = String.valueOf(vistaL.txtContrasenna.getPassword());

            if (consultas.iniciarSesion(correo, contrasenna)) {

                JOptionPane.showMessageDialog(null, "Inicio de sesión exitoso");

                vistaL.dispose();

                // Abrir Tienda (ventana principal)
                Tienda t = new Tienda();
                t.setLocationRelativeTo(null);
                t.setVisible(true);

            } else {
                JOptionPane.showMessageDialog(null, "Datos inválidos. Verifique correo y contraseña.");
            }
        }

        /* ----------------- IR A REGISTRO ----------------- */
        if (e.getSource() == vistaL.btnRegistrar) {
            vistaR.setVisible(true);
            vistaR.setLocationRelativeTo(null);
        }
    }

    private void limpiarRegistro() {
        vistaR.txtNombre.setText("");
        vistaR.txtCorreo.setText("");
        vistaR.txtCedula.setText("");
        vistaR.txtContrasenna1.setText("");
        vistaR.txtContrasenna2.setText("");
    }
}
