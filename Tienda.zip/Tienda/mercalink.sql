-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-11-2025 a las 03:58:30
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30


-- --------------------------------------------------------
-- BD MERCALINK 
-- --------------------------------------------------------

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";
SET NAMES utf8mb4;

-- --------------------------------------------------------
-- Tabla: usuario 
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `usuario` (
  `id` int(100) NOT NULL,
  `nombre` text NOT NULL,
  `correo` text NOT NULL,
  `contrasenna` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `usuario` (`id`, `nombre`, `correo`, `contrasenna`) VALUES
(123131123, 'correoelectrónico@dominio.com', 'correoelectrónico@dominio.com', 'correoelectrónico@dominio.com'),
(402510252, 'Ricardo', 'rzuniga0304@gmail.com', 'Ricardo123');

-- --------------------------------------------------------
-- Tabla: categoria
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `categoria` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(100) NOT NULL,
  `descripcion` VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO categoria (nombre, descripcion) VALUES
('Electrónica', 'Aparatos electrónicos en general'),
('Celulares', 'Teléfonos móviles y accesorios'),
('Computación', 'Laptops, piezas y periféricos');

-- --------------------------------------------------------
-- Tabla: proveedor
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `proveedor` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(150) NOT NULL,
  `telefono` VARCHAR(30),
  `correo` VARCHAR(150),
  `direccion` VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO proveedor (nombre, telefono, correo, direccion) VALUES
('Proveedor Tech S.A.', '8888-8888', 'info@techsa.com', 'San José, Costa Rica'),
('Electro Mundo', '7000-6000', 'ventas@electromundo.com', 'Heredia, Costa Rica');

-- --------------------------------------------------------
-- Tabla: colaborador
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `colaborador` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(150) NOT NULL,
  `correo` VARCHAR(150),
  `rol` VARCHAR(100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO colaborador (nombre, correo, rol) VALUES
('María Paz García', 'mpaz@gmail.com', 'Administradora'),
('Camila Vargas', 'cvargas@gmail.com', 'Inventario');

-- --------------------------------------------------------
-- Tabla: producto
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `producto` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(150) NOT NULL,
  `descripcion` VARCHAR(255),
  `precio` DECIMAL(10,2) NOT NULL,
  `cantidad` INT NOT NULL,
  `id_categoria` INT,
  `id_proveedor` INT,
  FOREIGN KEY (`id_categoria`) REFERENCES categoria(id),
  FOREIGN KEY (`id_proveedor`) REFERENCES proveedor(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO producto (nombre, descripcion, precio, cantidad, id_categoria, id_proveedor) VALUES
('Laptop Asus', 'Laptop para trabajo y estudio', 450000.00, 10, 3, 1),
('iPhone 14', 'Smartphone de última generación', 850000.00, 5, 2, 1),
('Audífonos Bluetooth', 'Audífonos inalámbricos', 25000.00, 20, 1, 2);

-- --------------------------------------------------------
-- Tabla: plan_lealtad
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `plan_lealtad` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(100) NOT NULL,
  `puntos_por_colon` DECIMAL(10,4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO plan_lealtad (nombre, puntos_por_colon) VALUES
('Plan Básico', 0.01),
('Plan Premium', 0.02);

-- --------------------------------------------------------
-- Tabla: puntos_cliente
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `puntos_cliente` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `id_usuario` INT NOT NULL,
  `puntos` INT DEFAULT 0,
  FOREIGN KEY (`id_usuario`) REFERENCES usuario(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO puntos_cliente (id_usuario, puntos) VALUES
(402510252, 150),
(123131123, 40);

-- --------------------------------------------------------
-- Tabla: promocion 
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `promocion` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(150) NOT NULL,
  `descripcion` VARCHAR(255),
  `descuento_porcentaje` DECIMAL(5,2),
  `producto_id` INT,
  FOREIGN KEY (`producto_id`) REFERENCES producto(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO promocion (nombre, descripcion, descuento_porcentaje, producto_id) VALUES
('Promoción de verano', '10% de descuento en audífonos', 10.00, 3);

COMMIT;
